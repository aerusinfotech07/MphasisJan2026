package com.company.ems.dao;

import java.util.ArrayList;
import java.util.List;

import com.company.ems.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{
	
	List<Employee> employeeList=new ArrayList<>();
	
	public EmployeeDAOImpl() {
		super();
		
		employeeList.add(new Employee(101, "Ram", "Sharma", "12/03/1990", 50000, "IT"));
		employeeList.add(new Employee(102, "Shyam", "Varma", "11/03/1995", 70000, "HR"));
		employeeList.add(new Employee(103, "Ravan", "XYZ", "05/03/1978", 45000, "SALES"));
		employeeList.add(new Employee(104, "Tanya", "Sharma", "08/03/1980", 20000, "IT"));
		employeeList.add(new Employee(105, "XYZ", "Varma", "29/03/1995", 67000, "SALES"));
		
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeList;
	}

	@Override
	public Employee findById(int id) {
		for(int i=0;i<employeeList.size();i++)
		{
			if(employeeList.get(i).getId()==id) {
				return employeeList.get(i);
			}	
		}
		return null;
	}

	@Override
	public Employee save(Employee employee) {
		employeeList.add(employee);
		return employee;
	}

	@Override
	public Employee update(Employee employee, int id) {
		for(int i=0;i<employeeList.size();i++)
		{
			if(employeeList.get(i).getId()==id) {
				employeeList.set(i,employee);
			}				
				
		}
		return employee;
	}

	@Override
	public boolean delete(int id) {
		boolean flag=false;
		for(int i=0;i<employeeList.size();i++)
		{
			if(employeeList.get(i).getId()==id) {
				employeeList.remove(i);
				flag=true;
			}				
				
		}
		
		
		return flag;
	}

}

package com.company.ems.service;

import java.util.List;

import com.company.ems.dao.EmployeeDAO;
import com.company.ems.dao.EmployeeDAOImpl;
import com.company.ems.dao.EmployeeJDBCDAOImpl;
import com.company.ems.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	private EmployeeDAO employeeDao=new EmployeeDAOImpl();
	private EmployeeDAO employeeDAO2=new EmployeeJDBCDAOImpl();

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDAO2.getAllEmployees();
	}

	@Override
	public Employee findById(int id) {
		// TODO Auto-generated method stub
		return employeeDAO2.findById(id);
	}

	@Override
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDAO2.save(employee);
	}

	@Override
	public Employee update(Employee employee, int id) {
		// TODO Auto-generated method stub
		return employeeDAO2.update(employee, id);
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return employeeDAO2.delete(id);
	}

}

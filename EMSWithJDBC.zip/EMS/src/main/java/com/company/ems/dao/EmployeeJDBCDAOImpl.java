package com.company.ems.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.company.ems.model.Employee;
import java.sql.PreparedStatement;

public class EmployeeJDBCDAOImpl implements EmployeeDAO{
	Connection connection=null;

	public EmployeeJDBCDAOImpl()
	{
		
	}
	
	public static Connection getConnection()
	{
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3310/ems", "root", "");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	
	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employeeList=new ArrayList<>();
		Connection conn=getConnection();
		Statement stmt=null;
		try {
			stmt=conn.createStatement();
			String sql="SELECT * FROM EMPLOYEE";
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next())
			{
				Employee employee=new Employee();
				employee.setId(rs.getInt("ID"));
				employee.setFirstName(rs.getString("FIRST_NAME"));
				employee.setLastName(rs.getString("LAST_NAME"));
				employee.setDob(rs.getString("DOB"));
				employee.setDept(rs.getString("DEPT"));
				employee.setSal(rs.getFloat("SAL"));
				employeeList.add(employee);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				stmt.close();			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return employeeList;
	}

	@Override
	public Employee findById(int id) {
		Connection conn=getConnection();
		PreparedStatement stmt=null;
		try {
			String sql="SELECT * FROM EMPLOYEE WHERE ID=?";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, id);
			ResultSet rs=stmt.executeQuery();
			if(rs.next())
			{
				Employee employee=new Employee();
				employee.setId(rs.getInt("ID"));
				employee.setFirstName(rs.getString("FIRST_NAME"));
				employee.setLastName(rs.getString("LAST_NAME"));
				employee.setDob(rs.getString("DOB"));
				employee.setDept(rs.getString("DEPT"));
				employee.setSal(rs.getFloat("SAL"));
				return employee;
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				stmt.close();			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return null;
	}

	@Override
	public Employee save(Employee employee) {

		Connection conn=getConnection();
		PreparedStatement stmt=null;
		try {
			String sql="INSERT INTO EMPLOYEE\r\n"
					+ "(id, FIRST_NAME, LAST_NAME, DOB, SAL, DEPT)\r\n"
					+ "VALUES\r\n"
					+ "(?,?,?,?,?,?)";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, employee.getId());
			stmt.setString(2, employee.getFirstName());
			stmt.setString(3, employee.getLastName());
			stmt.setString(4, employee.getDob());
			stmt.setFloat(5, employee.getSal());
			stmt.setString(6, employee.getDept());
			int no=stmt.executeUpdate();
			if(no>=0)
				return employee;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				stmt.close();			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return employee;
	
	}

	@Override
	public Employee update(Employee employee, int id) {

		Connection conn=getConnection();
		PreparedStatement stmt=null;
		try {
			String sql="UPDATE EMPLOYEE SET FIRST_NAME=?, LAST_NAME=?, DOB=?, SAL=?, DEPT=? WHERE ID=?";
			stmt=conn.prepareStatement(sql);
			
			stmt.setString(1, employee.getFirstName());
			stmt.setString(2, employee.getLastName());
			stmt.setString(3, employee.getDob());
			stmt.setFloat(4, employee.getSal());
			stmt.setString(5, employee.getDept());
			stmt.setInt(6, employee.getId());
			int no=stmt.executeUpdate();
			if(no>=0)
				return employee;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				stmt.close();			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return employee;
	
	}

	@Override
	public boolean delete(int id) {
		Connection conn=getConnection();
		PreparedStatement stmt=null;
		try {
			String sql="DELETE FROM EMPLOYEE WHERE ID=?";
			stmt=conn.prepareStatement(sql);
			stmt.setInt(1, id);
			int no=stmt.executeUpdate();
			if(no>=0)
				return true;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				stmt.close();			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

}

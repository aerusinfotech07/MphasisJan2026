package com.usermanagement.service;

import java.util.List;

import com.usermanagement.entity.Employee;

public interface EmployeeService {

	 public List<Employee> findAll();
	 public Employee findById(Long id);
	 public Employee findByEmployeeCode(String employeeCode);
	 public Employee findByEmail(String email);
	 public void save(Employee employee);
	 public void update(Employee employee);
	 public void delete(Long id);
	 
}

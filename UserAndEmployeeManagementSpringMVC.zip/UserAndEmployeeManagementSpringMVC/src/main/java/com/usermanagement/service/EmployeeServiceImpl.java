package com.usermanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usermanagement.dao.EmployeeDAO;
import com.usermanagement.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDAO employeeDAO;
	
	
	
	@Override
	public List<Employee> findAll() {
		return employeeDAO.findAll();
				
	}

	@Override
	public Employee findById(Long id) {
		// TODO Auto-generated method stub
		return employeeDAO.findById(id);
	}

	@Override
	public Employee findByEmployeeCode(String employeeCode) {
		// TODO Auto-generated method stub
		return employeeDAO.findByEmployeeCode(employeeCode);
	}

	@Override
	public Employee findByEmail(String email) {
		// TODO Auto-generated method stub
		return employeeDAO.findByEmail(email);
	}

	@Override
	public void save(Employee employee) {
		employeeDAO.save(employee);
		
	}

	@Override
	public void update(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		
	}

  
}

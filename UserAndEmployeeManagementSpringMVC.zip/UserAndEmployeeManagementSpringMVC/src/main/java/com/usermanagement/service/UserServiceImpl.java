package com.usermanagement.service;

import com.usermanagement.dao.UserDAOImpl;
import com.usermanagement.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl {

    @Autowired
    private UserDAOImpl userDAOImpl;

    public List<User> findAll() {
        return userDAOImpl.findAll();
    }

    public User findById(Long id) {
        return userDAOImpl.findById(id);
    }

    public User findByUsername(String username) {
        return userDAOImpl.findByUsername(username);
    }

    public User findByEmail(String email) {
        return userDAOImpl.findByEmail(email);
    }

    public void save(User user) {
        userDAOImpl.save(user);
    }

    public void update(User user) {
        userDAOImpl.update(user);
    }

    public void delete(Long id) {
        userDAOImpl.deleteById(id);
    }
}

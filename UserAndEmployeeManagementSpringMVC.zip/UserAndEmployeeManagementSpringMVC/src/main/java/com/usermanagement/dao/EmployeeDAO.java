package com.usermanagement.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.usermanagement.entity.Employee;


public interface EmployeeDAO {

	 public List<Employee> findAll();
	 public Employee findById(Long id);
	 public Employee findByEmployeeCode(String employeeCode);
	 public Employee findByEmail(String email);
	 public void save(Employee employee);
	 public void update(Employee employee);
	 public void delete(Long id);
}

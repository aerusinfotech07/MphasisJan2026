package com.company.ems.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CookieExample")
public class CookieExample extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, 
                       HttpServletResponse response)
            throws ServletException, IOException {
        
        // Create a cookie
        Cookie visitCookie = new Cookie("visitCount", "1");
        visitCookie.setMaxAge(60 * 60 * 24); // 24 hours
        visitCookie.setPath("/");
        response.addCookie(visitCookie);
        
        // Read cookies
        Cookie[] cookies = request.getCookies();
        int visitCount = 1;
        
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visitCount")) {
                    visitCount = Integer.parseInt(cookie.getValue()) + 1;
                    cookie.setValue(String.valueOf(visitCount));
                    cookie.setMaxAge(60 * 60 * 24);
                    response.addCookie(cookie);
                    break;
                }
            }
        }
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Cookie Example</title></head>");
        out.println("<body>");
        out.println("<h2>Cookie Information</h2>");
        out.println("<p>You have visited this page " + visitCount + " times.</p>");
        
        if (cookies != null) {
            out.println("<h3>All Cookies:</h3>");
            out.println("<ul>");
            for (Cookie cookie : cookies) {
                out.println("<li>" + cookie.getName() + " = " + cookie.getValue() + "</li>");
            }
            out.println("</ul>");
        }
        
        out.println("</body>");
        out.println("</html>");
    }
}
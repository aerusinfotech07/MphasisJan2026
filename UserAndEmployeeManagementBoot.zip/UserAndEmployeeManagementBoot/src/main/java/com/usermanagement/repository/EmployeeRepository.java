package com.usermanagement.repository;

import com.usermanagement.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Optional<Employee> findByEmployeeCode(String employeeCode);

    Optional<Employee> findByEmail(String email);

    boolean existsByEmployeeCode(String employeeCode);

    boolean existsByEmail(String email);

    List<Employee> findByDepartmentIgnoreCase(String department);

    List<Employee> findByDesignationIgnoreCase(String designation);

    List<Employee> findByDepartmentIgnoreCaseAndDesignationIgnoreCase(String department, String designation);

    List<Employee> findByNameContainingIgnoreCase(String name);

    List<Employee> findBySalaryBetween(Double minSalary, Double maxSalary);

    List<Employee> findByJoinDateBetween(Date startDate, Date endDate);

    @Query("select e from Employee e where " +
            "lower(e.name) like lower(concat('%', :keyword, '%')) " +
            "or lower(e.email) like lower(concat('%', :keyword, '%')) " +
            "or lower(e.employeeCode) like lower(concat('%', :keyword, '%'))")
    List<Employee> searchByKeyword(@Param("keyword") String keyword);

    @Query("select e from Employee e where e.salary >= :minSalary")
    List<Employee> findWithMinSalary(@Param("minSalary") Double minSalary);

    @Query("select e from Employee e where lower(e.department) = lower(:department) and e.salary >= :minSalary")
    List<Employee> findByDepartmentAndMinSalary(@Param("department") String department,
                                                @Param("minSalary") Double minSalary);

    @Query("select count(e) from Employee e where lower(e.department) = lower(:department)")
    long countByDepartmentQuery(@Param("department") String department);
}

package com.usermanagement.service;

import com.usermanagement.entity.Address;
import com.usermanagement.entity.Employee;
import com.usermanagement.exception.DuplicateResourceException;
import com.usermanagement.exception.ResourceNotFoundException;
import com.usermanagement.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
    }

    public Employee getEmployeeByEmployeeCode(String employeeCode) {
        return employeeRepository.findByEmployeeCode(employeeCode)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with code: " + employeeCode));
    }

    public Employee getEmployeeByEmail(String email) {
        return employeeRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with email: " + email));
    }

    public List<Employee> getEmployeesByDepartment(String department) {
        return employeeRepository.findByDepartmentIgnoreCase(department);
    }

    public List<Employee> getEmployeesByDesignation(String designation) {
        return employeeRepository.findByDesignationIgnoreCase(designation);
    }

    public List<Employee> getEmployeesByDepartmentAndDesignation(String department, String designation) {
        return employeeRepository.findByDepartmentIgnoreCaseAndDesignationIgnoreCase(department, designation);
    }

    public List<Employee> getEmployeesByName(String name) {
        return employeeRepository.findByNameContainingIgnoreCase(name);
    }

    public List<Employee> getEmployeesBySalaryRange(Double minSalary, Double maxSalary) {
        return employeeRepository.findBySalaryBetween(minSalary, maxSalary);
    }

    public List<Employee> getEmployeesByJoinDateRange(Date startDate, Date endDate) {
        return employeeRepository.findByJoinDateBetween(startDate, endDate);
    }

    public List<Employee> searchEmployees(String keyword) {
        return employeeRepository.searchByKeyword(keyword);
    }

    public List<Employee> getEmployeesWithMinSalary(Double minSalary) {
        return employeeRepository.findWithMinSalary(minSalary);
    }

    public List<Employee> getEmployeesByDepartmentAndMinSalary(String department, Double minSalary) {
        return employeeRepository.findByDepartmentAndMinSalary(department, minSalary);
    }

    public long getEmployeeCountByDepartment(String department) {
        return employeeRepository.countByDepartmentQuery(department);
    }

    public Employee createEmployee(Employee employee) {
        if (employeeRepository.existsByEmployeeCode(employee.getEmployeeCode())) {
            throw new DuplicateResourceException("Employee code already exists: " + employee.getEmployeeCode());
        }

        if (employeeRepository.existsByEmail(employee.getEmail())) {
            throw new DuplicateResourceException("Email already exists: " + employee.getEmail());
        }

        return employeeRepository.save(employee);
    }

    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));

        if (!employee.getEmployeeCode().equals(employeeDetails.getEmployeeCode())
                && employeeRepository.existsByEmployeeCode(employeeDetails.getEmployeeCode())) {
            throw new DuplicateResourceException("Employee code already exists: " + employeeDetails.getEmployeeCode());
        }

        if (!employee.getEmail().equals(employeeDetails.getEmail())
                && employeeRepository.existsByEmail(employeeDetails.getEmail())) {
            throw new DuplicateResourceException("Email already exists: " + employeeDetails.getEmail());
        }

        if(employeeDetails.getName()!=null)
        employee.setName(employeeDetails.getName());
        
        if(employeeDetails.getEmployeeCode()!=null)
        employee.setEmployeeCode(employeeDetails.getEmployeeCode());
        
        employee.setEmail(employeeDetails.getEmail());
        employee.setPhone(employeeDetails.getPhone());
        employee.setDesignation(employeeDetails.getDesignation());
        employee.setDepartment(employeeDetails.getDepartment());
        employee.setJoinDate(employeeDetails.getJoinDate());
        employee.setSalary(employeeDetails.getSalary());

        if (employeeDetails.getAddress() != null) {
            if (employee.getAddress() != null) {
                applyAddressUpdates(employee.getAddress(), employeeDetails.getAddress());
            } else {
                employee.setAddress(employeeDetails.getAddress());
            }
        }

        return employeeRepository.save(employee);
    }

    public void deleteEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
        employeeRepository.delete(employee);
    }

    private void applyAddressUpdates(Address existing, Address updates) {
        existing.setStreet(updates.getStreet());
        existing.setSuite(updates.getSuite());
        existing.setCity(updates.getCity());
        existing.setZipcode(updates.getZipcode());

        if (updates.getGeo() != null) {
            if (existing.getGeo() != null) {
                existing.getGeo().setLat(updates.getGeo().getLat());
                existing.getGeo().setLng(updates.getGeo().getLng());
            } else {
                existing.setGeo(updates.getGeo());
            }
        }
    }
}

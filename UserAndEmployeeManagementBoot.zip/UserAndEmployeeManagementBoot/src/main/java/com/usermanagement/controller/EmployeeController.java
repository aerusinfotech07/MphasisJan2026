package com.usermanagement.controller;

import com.usermanagement.entity.Employee;
import com.usermanagement.service.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.Valid;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE, RequestMethod.OPTIONS})
@Tag(name = "Employee Management", description = "Employee Management REST API endpoints")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    @Operation(summary = "Get all employees", description = "Retrieve a list of all employees")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved list of employees")
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get employee by ID", description = "Retrieve an employee by their unique ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Employee found", content = @Content(schema = @Schema(implementation = Employee.class))),
            @ApiResponse(responseCode = "404", description = "Employee not found")
    })
    public ResponseEntity<Employee> getEmployeeById(
            @Parameter(description = "Employee ID", required = true) @PathVariable Long id) {
        Employee employee = employeeService.getEmployeeById(id);
        return ResponseEntity.ok(employee);
    }

    @GetMapping("/code/{employeeCode}")
    @Operation(summary = "Get employee by code", description = "Retrieve an employee by their employee code")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Employee found", content = @Content(schema = @Schema(implementation = Employee.class))),
            @ApiResponse(responseCode = "404", description = "Employee not found")
    })
    public ResponseEntity<Employee> getEmployeeByEmployeeCode(
            @Parameter(description = "Employee code", required = true) @PathVariable String employeeCode) {
        Employee employee = employeeService.getEmployeeByEmployeeCode(employeeCode);
        return ResponseEntity.ok(employee);
    }

    @GetMapping("/email/{email}")
    @Operation(summary = "Get employee by email", description = "Retrieve an employee by their email address")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Employee found", content = @Content(schema = @Schema(implementation = Employee.class))),
            @ApiResponse(responseCode = "404", description = "Employee not found")
    })
    public ResponseEntity<Employee> getEmployeeByEmail(
            @Parameter(description = "Email address", required = true) @PathVariable String email) {
        Employee employee = employeeService.getEmployeeByEmail(email);
        return ResponseEntity.ok(employee);
    }

    @GetMapping("/search")
    @Operation(summary = "Search employees", description = "Search employees by name, email, or employee code")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> searchEmployees(
            @Parameter(description = "Search keyword", required = true) @RequestParam String keyword) {
        List<Employee> employees = employeeService.searchEmployees(keyword);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/min-salary")
    @Operation(summary = "Get employees with minimum salary", description = "Retrieve employees with salary greater than or equal to the provided value")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesWithMinSalary(
            @Parameter(description = "Minimum salary", required = true) @RequestParam("value") Double minSalary) {
        List<Employee> employees = employeeService.getEmployeesWithMinSalary(minSalary);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/department/{department}/min-salary")
    @Operation(summary = "Get employees by department and minimum salary",
            description = "Retrieve employees in a department with salary greater than or equal to the provided value")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesByDepartmentAndMinSalary(
            @Parameter(description = "Department", required = true) @PathVariable String department,
            @Parameter(description = "Minimum salary", required = true) @RequestParam("value") Double minSalary) {
        List<Employee> employees = employeeService.getEmployeesByDepartmentAndMinSalary(department, minSalary);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/department/{department}/count")
    @Operation(summary = "Count employees by department", description = "Get number of employees in a department")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employee count")
    public ResponseEntity<Map<String, Long>> getEmployeeCountByDepartment(
            @Parameter(description = "Department", required = true) @PathVariable String department) {
        long count = employeeService.getEmployeeCountByDepartment(department);
        Map<String, Long> response = new HashMap<>();
        response.put("count", count);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/department/{department}")
    @Operation(summary = "Get employees by department", description = "Retrieve employees by department")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesByDepartment(
            @Parameter(description = "Department", required = true) @PathVariable String department) {
        List<Employee> employees = employeeService.getEmployeesByDepartment(department);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/designation/{designation}")
    @Operation(summary = "Get employees by designation", description = "Retrieve employees by designation")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesByDesignation(
            @Parameter(description = "Designation", required = true) @PathVariable String designation) {
        List<Employee> employees = employeeService.getEmployeesByDesignation(designation);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/department/{department}/designation/{designation}")
    @Operation(summary = "Get employees by department and designation", description = "Retrieve employees by department and designation")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesByDepartmentAndDesignation(
            @Parameter(description = "Department", required = true) @PathVariable String department,
            @Parameter(description = "Designation", required = true) @PathVariable String designation) {
        List<Employee> employees = employeeService.getEmployeesByDepartmentAndDesignation(department, designation);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/name/{name}")
    @Operation(summary = "Search employees by name", description = "Retrieve employees whose names contain the given value")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesByName(
            @Parameter(description = "Name (partial match)", required = true) @PathVariable String name) {
        List<Employee> employees = employeeService.getEmployeesByName(name);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/salary")
    @Operation(summary = "Get employees by salary range", description = "Retrieve employees with salary between min and max")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesBySalaryRange(
            @Parameter(description = "Minimum salary", required = true) @RequestParam Double min,
            @Parameter(description = "Maximum salary", required = true) @RequestParam Double max) {
        List<Employee> employees = employeeService.getEmployeesBySalaryRange(min, max);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/joindate")
    @Operation(summary = "Get employees by join date range", description = "Retrieve employees whose join date is between from and to")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved employees")
    public ResponseEntity<List<Employee>> getEmployeesByJoinDateRange(
            @Parameter(description = "Start date (yyyy-MM-dd)", required = true)
            @RequestParam("from") @DateTimeFormat(pattern = "yyyy-MM-dd") Date from,
            @Parameter(description = "End date (yyyy-MM-dd)", required = true)
            @RequestParam("to") @DateTimeFormat(pattern = "yyyy-MM-dd") Date to) {
        List<Employee> employees = employeeService.getEmployeesByJoinDateRange(from, to);
        return ResponseEntity.ok(employees);
    }

    @PostMapping
    @Operation(summary = "Create a new employee", description = "Create a new employee with the provided details")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Employee created successfully", content = @Content(schema = @Schema(implementation = Employee.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input or validation failed"),
            @ApiResponse(responseCode = "409", description = "Employee code or email already exists")
    })
    public ResponseEntity<Employee> createEmployee(
            @Parameter(description = "Employee object to be created", required = true) @Valid @RequestBody Employee employee) {
        Employee createdEmployee = employeeService.createEmployee(employee);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployee);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing employee", description = "Update employee details by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Employee updated successfully", content = @Content(schema = @Schema(implementation = Employee.class))),
            @ApiResponse(responseCode = "404", description = "Employee not found"),
            @ApiResponse(responseCode = "400", description = "Invalid input or validation failed"),
            @ApiResponse(responseCode = "409", description = "Employee code or email already exists")
    })
    public ResponseEntity<Employee> updateEmployee(
            @Parameter(description = "Employee ID", required = true) @PathVariable Long id,
            @Parameter(description = "Updated employee object", required = true) @Valid @RequestBody Employee employeeDetails) {
        Employee updatedEmployee = employeeService.updateEmployee(id, employeeDetails);
        return ResponseEntity.ok(updatedEmployee);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an employee", description = "Delete an employee by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Employee deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Employee not found")
    })
    public ResponseEntity<Map<String, String>> deleteEmployee(
            @Parameter(description = "Employee ID", required = true) @PathVariable Long id) {
        employeeService.deleteEmployee(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", "Employee deleted successfully");
        return ResponseEntity.ok(response);
    }
}

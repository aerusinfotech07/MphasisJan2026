package com.usermanagement.entity;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Entity
@Table(name = "address")
public class Address implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Street is required")
    @Size(max = 100, message = "Street must be at most 100 characters")
    @Column(name = "street", nullable = false)
    private String street;

    @Size(max = 100, message = "Suite must be at most 100 characters")
    @Column(name = "suite")
    private String suite;

    @NotBlank(message = "City is required")
    @Size(max = 100, message = "City must be at most 100 characters")
    @Column(name = "city", nullable = false)
    private String city;

    @NotBlank(message = "Zipcode is required")
    @Size(max = 20, message = "Zipcode must be at most 20 characters")
    @Column(name = "zipcode", nullable = false)
    private String zipcode;

    @Valid
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "geo_id")
    private Geo geo;
    
    public Address() {
    }
    
    public Address(String street, String suite, String city, String zipcode, Geo geo) {
        this.street = street;
        this.suite = suite;
        this.city = city;
        this.zipcode = zipcode;
        this.geo = geo;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getStreet() {
        return street;
    }
    
    public void setStreet(String street) {
        this.street = street;
    }
    
    public String getSuite() {
        return suite;
    }
    
    public void setSuite(String suite) {
        this.suite = suite;
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    
    public String getZipcode() {
        return zipcode;
    }
    
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
    
    public Geo getGeo() {
        return geo;
    }
    
    public void setGeo(Geo geo) {
        this.geo = geo;
    }
}

<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<jsp:include page="/WEB-INF/jsp/common/header.jsp">
  <jsp:param name="pageTitle" value="View Employee" />
</jsp:include>

<c:url var="listUrl" value="EmployeeServlet" />
<c:url var="editUrl" value="EmployeeServlet">
  <c:param name="action" value="edit" />
  <c:param name="id" value="${employee.id}" />
</c:url>

<c:choose>
  <c:when test="${empty employee}">
    <p>Employee not found.</p>
    <p><a href="${listUrl}">Back to list</a></p>
  </c:when>
  <c:otherwise>
    <h2>Employee Details</h2>
    <table border="1" cellpadding="6">
      <tr><td>Id</td><td>${employee.id}</td></tr>
      <tr><td>First Name</td><td>${employee.firstName}</td></tr>
      <tr><td>Last Name</td><td>${employee.lastName}</td></tr>
      <tr><td>Email</td><td>${employee.email}</td></tr>
      <tr><td>User Name</td><td>${employee.userName}</td></tr>
      <tr><td>Password</td><td>${employee.password}</td></tr>
    </table>
    <p>
      <a href="${editUrl}">Edit</a> |
      <a href="${listUrl}">Back to list</a>
    </p>
  </c:otherwise>
</c:choose>

<jsp:include page="/WEB-INF/jsp/common/footer.jsp" />

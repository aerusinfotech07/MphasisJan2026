<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<jsp:include page="/WEB-INF/jsp/common/header.jsp">
  <jsp:param name="pageTitle" value="Employee Form" />
</jsp:include>

<c:set var="isEdit" value="${not empty employee}" />

<h2>${isEdit ? "Edit Employee" : "Add Employee"}</h2>
<form action="EmployeeServlet" method="post">
  <input type="hidden" name="action" value="${isEdit ? 'update' : 'create'}" />
  <input type="hidden" name="id" value="${employee.id}" />
  <table>
    <tr>
      <td>First Name</td>
      <td><input type="text" name="firstName" value="${employee.firstName}" required /></td>
    </tr>
    <tr>
      <td>Last Name</td>
      <td><input type="text" name="lastName" value="${employee.lastName}" required /></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><input type="email" name="email" value="${employee.email}" required /></td>
    </tr>
    <tr>
      <td>User Name</td>
      <td><input type="text" name="userName" value="${employee.userName}" required /></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type="password" name="password" value="${employee.password}" required /></td>
    </tr>
  </table>
  <input type="submit" value="${isEdit ? 'Update' : 'Create'}" />
  <a href="EmployeeServlet">Cancel</a>
</form>

<jsp:include page="/WEB-INF/jsp/common/footer.jsp" />

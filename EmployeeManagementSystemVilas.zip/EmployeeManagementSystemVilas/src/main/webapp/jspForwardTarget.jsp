<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<jsp:include page="/WEB-INF/jsp/common/header.jsp">
  <jsp:param name="pageTitle" value="Forward Target" />
</jsp:include>

<section>
  <h2>jsp:forward Result</h2>
  <p class="note">This page is the target of jsp:forward.</p>
  <table>
    <tr><th>Forwarded From</th><td>${param.from}</td></tr>
    <tr><th>Reason</th><td>${param.reason}</td></tr>
  </table>
  <p><a href="JspActionsDemo">Back to JSP Actions Demo</a></p>
</section>

<jsp:include page="/WEB-INF/jsp/common/footer.jsp" />

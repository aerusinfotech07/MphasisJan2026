<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="app" tagdir="/WEB-INF/tags" %>

<jsp:include page="/WEB-INF/jsp/common/header.jsp">
  <jsp:param name="pageTitle" value="JSP Actions and Tag Files" />
</jsp:include>

<section>
  <h2>JSP Action Tags</h2>
  <p class="note">This page is forwarded from <strong>JspActionsDemoServlet</strong> with request, session, and application data.</p>

  <h3>Real-time example (jsp:useBean + jsp:getProperty)</h3>
  <jsp:useBean id="now" class="java.util.Date" scope="page" />
  <p>Server time: ${now}</p>
  <p>Epoch millis (jsp:getProperty): <jsp:getProperty name="now" property="time" /></p>

  <h3>Forwarded Java object (request scope)</h3>
  <jsp:useBean id="demoEmployee" class="com.ems.model.Employee" scope="request" />
  <table>
    <tr><th>Id</th><td><jsp:getProperty name="demoEmployee" property="id" /></td></tr>
    <tr><th>First Name</th><td><jsp:getProperty name="demoEmployee" property="firstName" /></td></tr>
    <tr><th>Last Name</th><td><jsp:getProperty name="demoEmployee" property="lastName" /></td></tr>
    <tr><th>Email</th><td><jsp:getProperty name="demoEmployee" property="email" /></td></tr>
    <tr><th>User Name</th><td><jsp:getProperty name="demoEmployee" property="userName" /></td></tr>
  </table>
</section>

<section>
  <h2>Request / Session / Application Scope</h2>
  <table>
    <tr><th>Request Note</th><td>${requestScope.requestNote}</td></tr>
    <tr><th>Request Id</th><td>${requestScope.requestId}</td></tr>
    <tr><th>Session User</th><td>${sessionScope.sessionUser}</td></tr>
    <tr><th>Session Visit Count</th><td>${sessionScope.demoVisitCount}</td></tr>
    <tr><th>Application Counter</th><td>${applicationScope.demoAppCounter}</td></tr>
  </table>
</section>

<section>
  <h2>jsp:setProperty Example</h2>
  <p class="note">Submit the form to populate a bean using jsp:setProperty and then display it with jsp:getProperty.</p>
  <form action="JspActionsDemo" method="get">
    <div class="form-row">
      <label>First Name
        <input type="text" name="firstName" value="${param.firstName}" />
      </label>
      <label>Last Name
        <input type="text" name="lastName" value="${param.lastName}" />
      </label>
      <label>Email
        <input type="email" name="email" value="${param.email}" />
      </label>
    </div>
    <div style="margin-top: 10px;">
      <input type="submit" value="Populate Bean" />
    </div>
  </form>

  <jsp:useBean id="formEmployee" class="com.ems.model.Employee" scope="request" />
  <jsp:setProperty name="formEmployee" property="*" />

  <table>
    <tr><th>First Name</th><td><jsp:getProperty name="formEmployee" property="firstName" /></td></tr>
    <tr><th>Last Name</th><td><jsp:getProperty name="formEmployee" property="lastName" /></td></tr>
    <tr><th>Email</th><td><jsp:getProperty name="formEmployee" property="email" /></td></tr>
  </table>
</section>

<section>
  <h2>jsp:forward Example</h2>
  <p class="note">This link demonstrates jsp:forward and jsp:param in a separate JSP.</p>
  <p><a href="jspForwardController.jsp?reason=Review%20employee%20details">Forward to target page</a></p>
</section>

<section>
  <h2>JSP 2 Tag Files (Custom Tags)</h2>
  <app:infoBox title="Request Scope Message" variant="info" showTime="true">
    <p>${requestScope.requestNote}</p>
  </app:infoBox>

  <app:infoBox title="Session Stats" variant="success">
    <p>Visits in this session: ${sessionScope.demoVisitCount}</p>
  </app:infoBox>

  <p>
    <app:badge label="Neutral" />
    <app:badge label="Success" tone="success" />
    <app:badge label="Warning" tone="warning" />
    <app:badge label="Info" tone="info" />
  </p>
</section>

<jsp:include page="/WEB-INF/jsp/common/footer.jsp" />

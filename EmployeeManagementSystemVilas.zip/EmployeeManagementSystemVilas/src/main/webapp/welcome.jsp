<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<jsp:include page="/WEB-INF/jsp/common/header.jsp">
  <jsp:param name="pageTitle" value="Welcome" />
</jsp:include>

<h3>Welcome, ${empty param.username ? 'Guest' : param.username}!</h3>
<p>You have successfully logged in.</p>

<jsp:include page="/WEB-INF/jsp/common/footer.jsp" />

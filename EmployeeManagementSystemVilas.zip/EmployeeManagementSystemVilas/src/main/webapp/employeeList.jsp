<%@page import="com.ems.model.Employee"%>
<%@page import="java.util.List"%>
<%@page import="com.ems.dao.EmployeeDAOImpl"%>
<%@page import="com.ems.dao.EmployeeDAO"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<table border="2">
<tr>
<th>Id</th>
<th>firstName</th>
<th>lastName</th>
<th>email</th>
<th>userName</th>
<th>password</th>
<th>Action</th>
</tr>


<%
EmployeeDAO employeeDAO=new EmployeeDAOImpl();
List<Employee> empList=employeeDAO.findAllEmployees();
for(Employee employee:empList)
{
%>
<tr>
<td><%=employee.getId() %></td>
<td><%=employee.getFirstName() %></td>
<td><%=employee.getLastName() %></td>
<td><%=employee.getEmail() %></td>
<td><%=employee.getUserName() %></td>
<td><%=employee.getPassword() %></td>
<td>
<a href="EmployeeServlet?action=delete&id=<%=employee.getId() %>">Delete</a>
</td>
</tr>
<%			

}
%>
</table>
</body>
</html>
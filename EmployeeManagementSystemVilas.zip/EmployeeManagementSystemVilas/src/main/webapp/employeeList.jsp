<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<jsp:include page="/WEB-INF/jsp/common/header.jsp">
  <jsp:param name="pageTitle" value="Employees" />
</jsp:include>

<h2>Employees</h2>
<p><a href="EmployeeServlet?action=new">Add Employee</a></p>

<table border="1" cellpadding="6">
  <tr>
    <th>Id</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>
    <th>User Name</th>
    <th>Password</th>
    <th>Action</th>
  </tr>
  <c:choose>
    <c:when test="${empty employeeList}">
      <tr>
        <td colspan="7">No employees found.</td>
      </tr>
    </c:when>
    <c:otherwise>
      <c:forEach var="employee" items="${employeeList}">
        <c:url var="deleteUrl" value="EmployeeServlet">
          <c:param name="action" value="delete" />
          <c:param name="id" value="${employee.id}" />
        </c:url>
        <c:url var="viewUrl" value="EmployeeServlet">
          <c:param name="action" value="view" />
          <c:param name="id" value="${employee.id}" />
        </c:url>
        <c:url var="editUrl" value="EmployeeServlet">
          <c:param name="action" value="edit" />
          <c:param name="id" value="${employee.id}" />
        </c:url>
        <tr>
          <td>${employee.id}</td>
          <td>${employee.firstName}</td>
          <td>${employee.lastName}</td>
          <td>${employee.email}</td>
          <td>${employee.userName}</td>
          <td>${employee.password}</td>
          <td>
            <a href="${viewUrl}">View</a> |
            <a href="${editUrl}">Edit</a> |
            <a href="${deleteUrl}">Delete</a>
          </td>
        </tr>
      </c:forEach>
    </c:otherwise>
  </c:choose>
</table>

<jsp:include page="/WEB-INF/jsp/common/footer.jsp" />

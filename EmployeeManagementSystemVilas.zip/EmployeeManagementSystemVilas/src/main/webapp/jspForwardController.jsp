<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<jsp:forward page="jspForwardTarget.jsp">
  <jsp:param name="from" value="jspForwardController.jsp" />
  <jsp:param name="reason" value="${empty param.reason ? 'No reason provided' : param.reason}" />
</jsp:forward>

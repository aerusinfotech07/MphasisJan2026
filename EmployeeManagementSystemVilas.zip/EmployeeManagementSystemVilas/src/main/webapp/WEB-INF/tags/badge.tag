<%@ tag body-content="empty" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ attribute name="label" required="true" rtexprvalue="true" %>
<%@ attribute name="tone" required="false" rtexprvalue="true" %>

<c:set var="toneValue" value="${empty tone ? 'neutral' : tone}" />
<span class="badge badge-${toneValue}">${label}</span>

<%@ tag body-content="scriptless" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ attribute name="title" required="true" rtexprvalue="true" %>
<%@ attribute name="variant" required="false" rtexprvalue="true" %>
<%@ attribute name="showTime" required="false" type="java.lang.Boolean" rtexprvalue="true" %>

<c:set var="boxVariant" value="${empty variant ? 'info' : variant}" />
<c:set var="displayTime" value="${showTime == true}" />
<jsp:useBean id="tagNow" class="java.util.Date" scope="page" />

<div class="infobox infobox-${boxVariant}">
  <div class="infobox-title">${title}</div>
  <div class="infobox-body">
    <jsp:doBody />
  </div>
  <c:if test="${displayTime}">
    <div class="infobox-time">${tagNow}</div>
  </c:if>
</div>

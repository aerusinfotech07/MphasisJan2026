<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="pageTitle" value="${empty param.pageTitle ? 'Employee Management System' : param.pageTitle}" />
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>${pageTitle}</title>
<style>
:root {
  --brand: #15324b;
  --accent: #f5a623;
  --bg: #f5f7fb;
  --text: #1f2d3d;
  --muted: #667085;
  --card: #ffffff;
  --border: #e4e7ec;
}
* {
  box-sizing: border-box;
}
body {
  margin: 0;
  font-family: "Segoe UI", Tahoma, Arial, sans-serif;
  background: var(--bg);
  color: var(--text);
}
a {
  color: #1d4ed8;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}
.site-header {
  background: var(--brand);
  color: #fff;
  padding: 16px 24px;
}
.site-header .brand {
  font-size: 20px;
  font-weight: 600;
  letter-spacing: 0.3px;
}
.site-header nav {
  margin-top: 8px;
}
.site-header nav a {
  color: #fff;
  margin-right: 14px;
  font-size: 14px;
}
.page {
  max-width: 960px;
  margin: 24px auto;
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 24px;
  box-shadow: 0 6px 18px rgba(21, 50, 75, 0.08);
}
.page-title {
  margin: 0 0 16px;
  font-size: 24px;
}
section {
  margin-bottom: 24px;
}
table {
  border-collapse: collapse;
  width: 100%;
}
th, td {
  border: 1px solid var(--border);
  padding: 8px;
  text-align: left;
}
th {
  background: #f8fafc;
}
.form-row {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.form-row label {
  display: flex;
  flex-direction: column;
  font-size: 13px;
  color: var(--muted);
}
input[type="text"],
input[type="email"],
input[type="password"] {
  padding: 8px 10px;
  border: 1px solid var(--border);
  border-radius: 6px;
  min-width: 220px;
}
button,
input[type="submit"] {
  background: #1d4ed8;
  color: #fff;
  border: none;
  padding: 8px 14px;
  border-radius: 6px;
  cursor: pointer;
}
button:hover,
input[type="submit"]:hover {
  background: #1e40af;
}
.badge {
  display: inline-block;
  padding: 2px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
}
.badge-neutral {
  background: #e8eef5;
  color: #1f2d3d;
}
.badge-success {
  background: #ecfdf3;
  color: #027a48;
}
.badge-warning {
  background: #fffaeb;
  color: #b54708;
}
.badge-info {
  background: #eef4ff;
  color: #1d4ed8;
}
.infobox {
  border: 1px solid var(--border);
  border-left: 4px solid var(--accent);
  padding: 12px;
  border-radius: 8px;
  background: #fff;
}
.infobox-info {
  border-left-color: #1d4ed8;
}
.infobox-success {
  border-left-color: #12b76a;
}
.infobox-warning {
  border-left-color: #f79009;
}
.infobox-danger {
  border-left-color: #f04438;
}
.infobox-title {
  font-weight: 600;
  margin-bottom: 6px;
}
.infobox-time {
  font-size: 12px;
  color: var(--muted);
  margin-top: 6px;
}
.note {
  font-size: 13px;
  color: var(--muted);
}
.site-footer {
  text-align: center;
  padding: 18px 12px;
  color: var(--muted);
  font-size: 12px;
}
</style>
</head>
<body>
<header class="site-header">
  <div class="brand">Employee Management System</div>
  <nav>
    <a href="EmployeeServlet">Employees</a>
    <a href="EmployeeServlet?action=new">Add Employee</a>
    <a href="login.jsp">Login</a>
    <a href="JspActionsDemo">JSP Actions Demo</a>
  </nav>
</header>
<main class="page">
  <h1 class="page-title">${pageTitle}</h1>

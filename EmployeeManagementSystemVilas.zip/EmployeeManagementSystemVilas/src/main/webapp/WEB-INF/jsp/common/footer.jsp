<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
</main>
<footer class="site-footer">
  <div>EMS Demo Footer - Built with JSP</div>
</footer>
</body>
</html>

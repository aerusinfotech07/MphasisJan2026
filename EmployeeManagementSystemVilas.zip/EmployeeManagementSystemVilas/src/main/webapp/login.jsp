<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<jsp:include page="/WEB-INF/jsp/common/header.jsp">
  <jsp:param name="pageTitle" value="Login" />
</jsp:include>

<h3>Login Page</h3>
<form action="LoginServlet" method="post">
  Username: <input type="text" name="username"><br/>
  Password: <input type="password" name="password"><br/>
  <input type="submit" value="Login">
</form>

<% if(request.getAttribute("error") != null) { %>
  <p style="color: red;"><%= request.getAttribute("error") %></p>
<% } %>

<jsp:include page="/WEB-INF/jsp/common/footer.jsp" />

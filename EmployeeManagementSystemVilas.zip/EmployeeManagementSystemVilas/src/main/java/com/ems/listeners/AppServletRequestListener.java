package com.ems.listeners;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;

@WebListener
public class AppServletRequestListener implements ServletRequestListener {
	@Override
	public void requestInitialized(ServletRequestEvent sre) {
		if (sre.getServletRequest() instanceof HttpServletRequest) {
			HttpServletRequest req = (HttpServletRequest) sre.getServletRequest();
			System.out.println("[Request] " + req.getMethod() + " " + req.getRequestURI());
		} else {
			System.out.println("[Request] Initialized");
		}
	}

	@Override
	public void requestDestroyed(ServletRequestEvent sre) {
		if (sre.getServletRequest() instanceof HttpServletRequest) {
			HttpServletRequest req = (HttpServletRequest) sre.getServletRequest();
			System.out.println("[Request] Completed " + req.getMethod() + " " + req.getRequestURI());
		} else {
			System.out.println("[Request] Destroyed");
		}
	}
}

package com.ems.listeners;

import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class AppServletContextListener implements ServletContextListener {
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		ServletContext ctx = sce.getServletContext();
		ctx.setAttribute("appStartTime", System.currentTimeMillis());
		ctx.setAttribute("activeSessions", new AtomicInteger(0));
		System.out.println("[Context] Initialized: " + ctx.getContextPath());
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		ServletContext ctx = sce.getServletContext();
		System.out.println("[Context] Destroyed: " + ctx.getContextPath());
	}
}

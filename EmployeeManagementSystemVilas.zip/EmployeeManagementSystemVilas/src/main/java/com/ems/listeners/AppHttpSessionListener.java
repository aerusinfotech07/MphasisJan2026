package com.ems.listeners;

import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class AppHttpSessionListener implements HttpSessionListener {
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		ServletContext ctx = se.getSession().getServletContext();
		AtomicInteger active = getCounter(ctx);
		int count = active.incrementAndGet();
		System.out.println("[Session] Created: " + se.getSession().getId() + " | active=" + count);
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		ServletContext ctx = se.getSession().getServletContext();
		AtomicInteger active = getCounter(ctx);
		int count = active.decrementAndGet();
		System.out.println("[Session] Destroyed: " + se.getSession().getId() + " | active=" + count);
	}

	private AtomicInteger getCounter(ServletContext ctx) {
		AtomicInteger active = (AtomicInteger) ctx.getAttribute("activeSessions");
		if (active == null) {
			active = new AtomicInteger(0);
			ctx.setAttribute("activeSessions", active);
		}
		return active;
	}
}

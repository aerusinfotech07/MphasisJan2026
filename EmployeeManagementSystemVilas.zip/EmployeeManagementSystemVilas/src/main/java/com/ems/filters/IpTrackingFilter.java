package com.ems.filters;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class IpTrackingFilter
 */
@WebFilter("/*")
public class IpTrackingFilter extends HttpFilter implements Filter {
       
    /**
     * @see HttpFilter#HttpFilter()
     */
    public IpTrackingFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		System.out.println("IpTrackingFilter Called");
		HttpServletRequest httpRequest=(HttpServletRequest)request;
		Map<String,String[]> map=httpRequest.getParameterMap();
		map.forEach((k,v)->{
			System.out.println(k+" "+Arrays.asList(v));
		});
		
		// Log request information
        String ipAddress = httpRequest.getRemoteAddr();
        String requestURI = httpRequest.getRequestURI();
        String method = httpRequest.getMethod();
        Date timestamp = new Date();
        
        System.out.println("[" + timestamp + "] " + method + " " + 
                          requestURI + " from IP: " + ipAddress);
        
		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}

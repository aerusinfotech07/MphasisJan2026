package com.ems.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ems.dao.EmployeeDAO;
import com.ems.dao.EmployeeDAOImpl;
import com.ems.model.Employee;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String action=request.getParameter("action");
		System.out.println("Action="+action);
		
		Cookie[] cookies=request.getCookies();
		if(cookies!=null && cookies.length>0)
		{
			System.out.println("Cookies List");
			for(Cookie coo:cookies)
			{
				System.out.println("Name="+coo.getName()+" Value="+coo.getValue()+" Age="+coo.getMaxAge()+" ");
			}
		}
		
		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
		if(action!=null && action.equalsIgnoreCase("delete")) {
			String id=request.getParameter("id");
			employeeDAO.deleteById(Integer.parseInt(id));
			System.out.println("Recotrd Deleted Successfully");
//			List<Employee> empList=employeeDAO.findAllEmployees();
//			session.setAttribute("employeeList", empList);
//			response.sendRedirect("employeeList.jsp");
			request.setAttribute("employeeList", employeeDAO.findAllEmployees());
			request.getRequestDispatcher("employeeList.jsp").forward(request, response);
		}
		else if(action!=null && action.equalsIgnoreCase("view")) {
			String id=request.getParameter("id");
			Employee employee=employeeDAO.findById(Integer.parseInt(id));
//			session.setAttribute("employee", employee);
//			response.sendRedirect("viewEmployee.jsp");
			request.setAttribute("employee", employee);
			request.getRequestDispatcher("viewEmployee.jsp").forward(request, response);
		}
		else if(action!=null && action.equalsIgnoreCase("edit")) {
//			session.setAttribute("employee", employee);
//			response.sendRedirect("addEmployee.jsp");
			request.setAttribute("employee", 
					employeeDAO.findById(Integer.parseInt(
						request.getParameter("id"))));
			request.getRequestDispatcher("addEmployee.jsp")
				.forward(request, response);
		}
		else if(action!=null && action.equalsIgnoreCase("new")) {
//			session.setAttribute("employee", null);
//			response.sendRedirect("addEmployee.jsp");
			request.getRequestDispatcher("addEmployee.jsp").forward(request, response);
		}
		else
		{
//			List<Employee> empList=employeeDAO.findAllEmployees();
//			session.setAttribute("employeeList", empList);
//			response.sendRedirect("employeeList.jsp");
			request.setAttribute("employeeList", employeeDAO.findAllEmployees());
			request.getRequestDispatcher("employeeList.jsp").forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
		String id=request.getParameter("id");
		String action=request.getParameter("action");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String email=request.getParameter("email");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		
		Employee employeeAdd=new Employee();
		employeeAdd.setFirstName(firstName);
		employeeAdd.setLastName(lastName);
		employeeAdd.setEmail(email);
		employeeAdd.setUserName(userName);
		employeeAdd.setPassword(password);
		if(action!=null && action.equalsIgnoreCase("update"))
			employeeDAO.update(employeeAdd,Integer.parseInt(id));
		else
			employeeDAO.save(employeeAdd);
		System.out.println("Employee Save Sucessfully");
	
		
		doGet(request, response);
	}

}

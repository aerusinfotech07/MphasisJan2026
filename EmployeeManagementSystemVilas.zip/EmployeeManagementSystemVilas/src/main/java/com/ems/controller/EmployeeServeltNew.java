package com.ems.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.dao.EmployeeDAO;
import com.ems.dao.EmployeeDAOImpl;
import com.ems.model.Employee;

@WebServlet("/EmployeeServeltNew")
public class EmployeeServeltNew extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final EmployeeDAO employeeDAO = new EmployeeDAOImpl();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = valueOrDefault(request.getParameter("action"), "list");

		switch (action.toLowerCase()) {
		case "new":
			showForm(request, response, null);
			break;
		case "edit":
			showForm(request, response, employeeDAO.findById(parseId(request)));
			break;
		case "view":
			showView(request, response, employeeDAO.findById(parseId(request)));
			break;
		case "delete":
			employeeDAO.deleteById(parseId(request));
			redirectToList(request, response);
			break;
		default:
			showList(request, response);
			break;
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = valueOrDefault(request.getParameter("action"), "create");
		Employee employee = bindEmployee(request);

		if ("update".equalsIgnoreCase(action)) {
			employeeDAO.update(employee, employee.getId());
		} else {
			employeeDAO.save(employee);
		}
		redirectToList(request, response);
	}

	private void showList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("employeeList", employeeDAO.findAllEmployees());
		request.getRequestDispatcher("employeeList.jsp").forward(request, response);
	}

	private void showForm(HttpServletRequest request, HttpServletResponse response, Employee employee)
			throws ServletException, IOException {
		request.setAttribute("employee", employee);
		request.getRequestDispatcher("addEmployee.jsp").forward(request, response);
	}

	private void showView(HttpServletRequest request, HttpServletResponse response, Employee employee)
			throws ServletException, IOException {
		if (employee == null) {
			redirectToList(request, response);
			return;
		}
		request.setAttribute("employee", employee);
		request.getRequestDispatcher("viewEmployee.jsp").forward(request, response);
	}

	private void redirectToList(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.sendRedirect(request.getContextPath() + "/EmployeeServlet");
	}

	private int parseId(HttpServletRequest request) {
		String id = request.getParameter("id");
		return id == null || id.isEmpty() ? 0 : Integer.parseInt(id);
	}

	private Employee bindEmployee(HttpServletRequest request) {
		Employee employee = new Employee();
		String id = request.getParameter("id");
		if (id != null && !id.isEmpty()) {
			employee.setId(Integer.parseInt(id));
		}
		employee.setFirstName(request.getParameter("firstName"));
		employee.setLastName(request.getParameter("lastName"));
		employee.setEmail(request.getParameter("email"));
		employee.setUserName(request.getParameter("userName"));
		employee.setPassword(request.getParameter("password"));
		return employee;
	}

	private String valueOrDefault(String value, String defaultValue) {
		return value == null || value.trim().isEmpty() ? defaultValue : value.trim();
	}
}

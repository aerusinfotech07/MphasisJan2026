package com.ems.controller;

import java.io.IOException;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ems.model.Employee;

@WebServlet("/JspActionsDemo")
public class JspActionsDemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Employee demoEmployee = new Employee();
		demoEmployee.setId(101);
		demoEmployee.setFirstName("Asha");
		demoEmployee.setLastName("Patel");
		demoEmployee.setEmail("asha.patel@demo.local");
		demoEmployee.setUserName("asha.p");
		demoEmployee.setPassword("demo123");
		request.setAttribute("demoEmployee", demoEmployee);

		request.setAttribute("requestNote", "Request scope data created at " + new Date());
		request.setAttribute("requestId", UUID.randomUUID().toString());

		HttpSession session = request.getSession();
		Integer visitCount = (Integer) session.getAttribute("demoVisitCount");
		if (visitCount == null) {
			visitCount = 0;
		}
		visitCount++;
		session.setAttribute("demoVisitCount", visitCount);

		if (session.getAttribute("sessionUser") == null) {
			String user = request.getParameter("username");
			session.setAttribute("sessionUser", (user == null || user.trim().isEmpty()) ? "demo-user" : user);
		}

		ServletContext context = getServletContext();
		AtomicInteger appCounter = (AtomicInteger) context.getAttribute("demoAppCounter");
		if (appCounter == null) {
			appCounter = new AtomicInteger(0);
			context.setAttribute("demoAppCounter", appCounter);
		}
		appCounter.incrementAndGet();

		RequestDispatcher dispatcher = request.getRequestDispatcher("jspActionsDemo.jsp");
		dispatcher.forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}

package com.ems.dao;

import java.util.List;

import com.ems.model.Employee;

public interface EmployeeDAO {
	
	List<Employee> findAllEmployees();
	boolean deleteById(int id);
	Employee save(Employee employee);
	Employee update(Employee employee,int id);
	Employee findByUserName(String userName);
	Employee findById(int id);

}

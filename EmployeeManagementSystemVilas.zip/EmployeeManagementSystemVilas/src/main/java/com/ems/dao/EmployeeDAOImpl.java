package com.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ems.model.Employee;
import com.ems.utility.DBConnection;

public class EmployeeDAOImpl implements EmployeeDAO {
	private static final String SELECT_ALL =
			"select id, first_name, last_name, email, user_name, password from employee";
	private static final String SELECT_BY_ID = SELECT_ALL + " where id=?";
	private static final String SELECT_BY_USERNAME = SELECT_ALL + " where user_name=?";
	private static final String INSERT_SQL =
			"insert into employee(first_name,last_name,email,user_name,password) values(?,?,?,?,?)";
	private static final String UPDATE_SQL =
			"update employee set first_name=?,last_name=?,email=?,user_name=?,password=? where id=?";
	private static final String DELETE_SQL = "delete from employee where id=?";

	@Override
	public List<Employee> findAllEmployees() {
		List<Employee> employeeList = new ArrayList<>();
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(SELECT_ALL);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				employeeList.add(mapRow(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employeeList;
	}

	@Override
	public boolean deleteById(int id) {
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {
			ps.setInt(1, id);
			return ps.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public Employee save(Employee employee) {
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {
			setEmployeeParams(ps, employee);
			if (ps.executeUpdate() > 0) {
				try (ResultSet keys = ps.getGeneratedKeys()) {
					if (keys.next()) {
						employee.setId(keys.getInt(1));
					}
				}
				return employee;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Employee update(Employee employee, int id) {
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {
			setEmployeeParams(ps, employee);
			ps.setInt(6, id);
			return ps.executeUpdate() > 0 ? employee : null;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Employee findByUserName(String userName) {
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(SELECT_BY_USERNAME)) {
			ps.setString(1, userName);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() ? mapRow(rs) : null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Employee findById(int id) {
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID)) {
			ps.setInt(1, id);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() ? mapRow(rs) : null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	private Employee mapRow(ResultSet rs) throws SQLException {
		Employee employee = new Employee();
		employee.setId(rs.getInt("id"));
		employee.setFirstName(rs.getString("first_name"));
		employee.setLastName(rs.getString("last_name"));
		employee.setEmail(rs.getString("email"));
		employee.setUserName(rs.getString("user_name"));
		employee.setPassword(rs.getString("password"));
		return employee;
	}

	private void setEmployeeParams(PreparedStatement ps, Employee employee) throws SQLException {
		ps.setString(1, employee.getFirstName());
		ps.setString(2, employee.getLastName());
		ps.setString(3, employee.getEmail());
		ps.setString(4, employee.getUserName());
		ps.setString(5, employee.getPassword());
	}
}

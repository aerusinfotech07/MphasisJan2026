package com.ems.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ems.model.Employee;
import com.ems.utility.DBConnection;
import java.sql.PreparedStatement;

public class EmployeeDAOImpl implements EmployeeDAO{

	@Override
	public List<Employee> findAllEmployees() {
		Connection conn=DBConnection.getConnection();
		Statement stmt;
		ResultSet rs;
		List<Employee> employeeList=new ArrayList<>();
		try {
			stmt = conn.createStatement();
			rs=stmt.executeQuery("select * from Employee");
			while(rs.next())
			{
				Employee employee=new Employee();
				employee.setId(rs.getInt("id"));
				employee.setFirstName(rs.getString("FIRST_NAME"));
				employee.setLastName(rs.getString("LAST_NAME"));
				employee.setEmail(rs.getString("EMAIL"));
				employee.setUserName(rs.getString("USER_NAME"));
				employee.setPassword(rs.getString("PASSWORD"));
				employeeList.add(employee);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return employeeList;
	}

	@Override
	public boolean deleteById(int id) {
		Connection connection=DBConnection.getConnection();
		try {
			Statement statement=connection.createStatement();
			int noOfRecordsDeleted=statement.executeUpdate("delete from employee where id="+id);
			if(noOfRecordsDeleted>0)
				return true;
			else
				return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public Employee save(Employee employee) {
		Connection connection=DBConnection.getConnection();
		try {
			String sql="insert into employee(first_name,last_name,email,user_name,password) values(?,?,?,?,?)";
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1, employee.getFirstName());
			statement.setString(2, employee.getLastName());
			statement.setString(3, employee.getEmail());
			statement.setString(4, employee.getUserName());
			statement.setString(5, employee.getPassword());
			int noOfRecordsDeleted=statement
					.executeUpdate();
			if(noOfRecordsDeleted>0)
				return employee;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employee;
	}

	@Override
	public Employee update(Employee employee, int id) {
		Connection connection=DBConnection.getConnection();
		try {
			String sql="update employee set first_name=?,last_name=?,email=?,user_name=?,password=? where id=?";
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1, employee.getFirstName());
			statement.setString(2, employee.getLastName());
			statement.setString(3, employee.getEmail());
			statement.setString(4, employee.getUserName());
			statement.setString(5, employee.getPassword());
			statement.setInt(6, id);
			int noOfRecordsDeleted=statement
					.executeUpdate();
			if(noOfRecordsDeleted>0)
				return employee;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employee;
	}

	@Override
	public Employee findByUserName(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findById(int id) {
		Connection conn=DBConnection.getConnection();
		Statement stmt;
		ResultSet rs;
		try {
			stmt = conn.createStatement(); 
			rs=stmt.executeQuery("select * from Employee where id="+id);
			if(rs.next())
			{
				Employee employee=new Employee();
				employee.setId(rs.getInt("id"));
				employee.setFirstName(rs.getString("FIRST_NAME"));
				employee.setLastName(rs.getString("LAST_NAME"));
				employee.setEmail(rs.getString("EMAIL"));
				employee.setUserName(rs.getString("USER_NAME"));
				employee.setPassword(rs.getString("PASSWORD"));
				return employee;
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return null;
	}
	
	public static void main(String args[])
	{
		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
		List<Employee> emplList=employeeDAO.findAllEmployees();
		System.out.println("No Of records="+emplList.size());
		
		Employee employee=new Employee();
		employee.setFirstName("Ramu");
		employee.setLastName("Sharma");
		employee.setEmail("ramu.sharma@gmail.com");
		employee.setUserName("ramu_sharma");
		employee.setPassword("Password@123");
		employeeDAO.save(employee);
		emplList=employeeDAO.findAllEmployees();
		System.out.println("After Saved No Of records="+emplList.size());
		
		employee=employeeDAO.findById(50);
		if(employee!=null)
			System.out.println("employee with id=50 is "+employee.getFirstName()+" "+employee.getLastName());
		
		
		
		
		
		
		
	}
	
	

}

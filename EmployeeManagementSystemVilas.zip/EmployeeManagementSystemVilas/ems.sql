/*
MySQL Data Transfer
Source Host: localhost
Source Database: ems
Target Host: localhost
Target Database: ems
Date: 28-03-2026 14:37:22
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for employee
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `employee` VALUES ('1', 'Amit', 'Sharma', 'amit.sharma1@gmail.com', 'amit1', 'pass123');
INSERT INTO `employee` VALUES ('2', 'Rahul', 'Verma', 'rahul.verma2@gmail.com', 'rahul2', 'pass123');
INSERT INTO `employee` VALUES ('3', 'Priya', 'Patel', 'priya.patel3@gmail.com', 'priya3', 'pass123');
INSERT INTO `employee` VALUES ('4', 'Neha', 'Gupta', 'neha.gupta4@gmail.com', 'neha4', 'pass123');
INSERT INTO `employee` VALUES ('5', 'Vikas', 'Yadav', 'vikas.yadav5@gmail.com', 'vikas5', 'pass123');
INSERT INTO `employee` VALUES ('6', 'Anjali', 'Singh', 'anjali.singh6@gmail.com', 'anjali6', 'pass123');
INSERT INTO `employee` VALUES ('8', 'Sneha', 'Joshi', 'sneha.joshi8@gmail.com', 'sneha8', 'pass123');
INSERT INTO `employee` VALUES ('9', 'Pooja', 'Mehta', 'pooja.mehta9@gmail.com', 'pooja9', 'pass123');
INSERT INTO `employee` VALUES ('11', 'Deepak', 'Sharma', 'deepak.sharma11@gmail.com', 'deepak11', 'pass123');
INSERT INTO `employee` VALUES ('12', 'Sanjay', 'Verma', 'sanjay.verma12@gmail.com', 'sanjay12', 'pass123');
INSERT INTO `employee` VALUES ('13', 'Ritu', 'Patel', 'ritu.patel13@gmail.com', 'ritu13', 'pass123');
INSERT INTO `employee` VALUES ('14', 'Manish', 'Gupta', 'manish.gupta14@gmail.com', 'manish14', 'pass123');
INSERT INTO `employee` VALUES ('15', 'Sunita', 'Yadav', 'sunita.yadav15@gmail.com', 'sunita15', 'pass123');
INSERT INTO `employee` VALUES ('16', 'Kavita', 'Singh', 'kavita.singh16@gmail.com', 'kavita16', 'pass123');
INSERT INTO `employee` VALUES ('17', 'Ajay', 'Kumar', 'ajay.kumar17@gmail.com', 'ajay17', 'pass123');
INSERT INTO `employee` VALUES ('18', 'Nisha', 'Joshi', 'nisha.joshi18@gmail.com', 'nisha18', 'pass123');
INSERT INTO `employee` VALUES ('19', 'Meena', 'Mehta', 'meena.mehta19@gmail.com', 'meena19', 'pass123');
INSERT INTO `employee` VALUES ('20', 'Arjun', 'Agarwal', 'arjun.agarwal20@gmail.com', 'arjun20', 'pass123');
INSERT INTO `employee` VALUES ('21', 'Rakesh', 'Sharma', 'rakesh.sharma21@gmail.com', 'rakesh21', 'pass123');
INSERT INTO `employee` VALUES ('22', 'Suresh', 'Verma', 'suresh.verma22@gmail.com', 'suresh22', 'pass123');
INSERT INTO `employee` VALUES ('23', 'Alok', 'Patel', 'alok.patel23@gmail.com', 'alok23', 'pass123');
INSERT INTO `employee` VALUES ('24', 'Seema', 'Gupta', 'seema.gupta24@gmail.com', 'seema24', 'pass123');
INSERT INTO `employee` VALUES ('25', 'Rekha', 'Yadav', 'rekha.yadav25@gmail.com', 'rekha25', 'pass123');
INSERT INTO `employee` VALUES ('26', 'Vijay', 'Singh', 'vijay.singh26@gmail.com', 'vijay26', 'pass123');
INSERT INTO `employee` VALUES ('27', 'Gaurav', 'Kumar', 'gaurav.kumar27@gmail.com', 'gaurav27', 'pass123');
INSERT INTO `employee` VALUES ('28', 'Swati', 'Joshi', 'swati.joshi28@gmail.com', 'swati28', 'pass123');
INSERT INTO `employee` VALUES ('29', 'Payal', 'Mehta', 'payal.mehta29@gmail.com', 'payal29', 'pass123');
INSERT INTO `employee` VALUES ('30', 'Nitin', 'Agarwal', 'nitin.agarwal30@gmail.com', 'nitin30', 'pass123');
INSERT INTO `employee` VALUES ('31', 'Mohit', 'Sharma', 'mohit.sharma31@gmail.com', 'mohit31', 'pass123');
INSERT INTO `employee` VALUES ('32', 'Tarun', 'Verma', 'tarun.verma32@gmail.com', 'tarun32', 'pass123');
INSERT INTO `employee` VALUES ('33', 'Divya', 'Patel', 'divya.patel33@gmail.com', 'divya33', 'pass123');
INSERT INTO `employee` VALUES ('34', 'Pankaj', 'Gupta', 'pankaj.gupta34@gmail.com', 'pankaj34', 'pass123');
INSERT INTO `employee` VALUES ('35', 'Kiran', 'Yadav', 'kiran.yadav35@gmail.com', 'kiran35', 'pass123');
INSERT INTO `employee` VALUES ('36', 'Komal', 'Singh', 'komal.singh36@gmail.com', 'komal36', 'pass123');
INSERT INTO `employee` VALUES ('37', 'Ankit', 'Kumar', 'ankit.kumar37@gmail.com', 'ankit37', 'pass123');
INSERT INTO `employee` VALUES ('38', 'Rashmi', 'Joshi', 'rashmi.joshi38@gmail.com', 'rashmi38', 'pass123');
INSERT INTO `employee` VALUES ('39', 'Sakshi', 'Mehta', 'sakshi.mehta39@gmail.com', 'sakshi39', 'pass123');
INSERT INTO `employee` VALUES ('40', 'Varun', 'Agarwal', 'varun.agarwal40@gmail.com', 'varun40', 'pass123');
INSERT INTO `employee` VALUES ('41', 'Harsh', 'Sharma', 'harsh.sharma41@gmail.com', 'harsh41', 'pass123');
INSERT INTO `employee` VALUES ('42', 'Lokesh', 'Verma', 'lokesh.verma42@gmail.com', 'lokesh42', 'pass123');
INSERT INTO `employee` VALUES ('43', 'Aarti', 'Patel', 'aarti.patel43@gmail.com', 'aarti43', 'pass123');
INSERT INTO `employee` VALUES ('44', 'Bhavesh', 'Gupta', 'bhavesh.gupta44@gmail.com', 'bhavesh44', 'pass123');
INSERT INTO `employee` VALUES ('45', 'Jyoti', 'Yadav', 'jyoti.yadav45@gmail.com', 'jyoti45', 'pass123');
INSERT INTO `employee` VALUES ('46', 'Preeti', 'Singh', 'preeti.singh46@gmail.com', 'preeti46', 'pass123');
INSERT INTO `employee` VALUES ('47', 'Naveen', 'Kumar', 'naveen.kumar47@gmail.com', 'naveen47', 'pass123');
INSERT INTO `employee` VALUES ('48', 'Tina', 'Joshi', 'tina.joshi48@gmail.com', 'tina48', 'pass123');
INSERT INTO `employee` VALUES ('49', 'Mansi', 'Mehta', 'mansi.mehta49@gmail.com', 'mansi49', 'pass123');
INSERT INTO `employee` VALUES ('50', 'Yash', 'Agarwal', 'yash.agarwal50@gmail.com', 'yash50', 'pass123');
INSERT INTO `employee` VALUES ('51', 'Abhishek', 'Sharma', 'abhishek.sharma51@gmail.com', 'abhishek51', 'pass123');
INSERT INTO `employee` VALUES ('52', 'Hemant', 'Verma', 'hemant.verma52@gmail.com', 'hemant52', 'pass123');
INSERT INTO `employee` VALUES ('53', 'Isha', 'Patel', 'isha.patel53@gmail.com', 'isha53', 'pass123');
INSERT INTO `employee` VALUES ('54', 'Kapil', 'Gupta', 'kapil.gupta54@gmail.com', 'kapil54', 'pass123');
INSERT INTO `employee` VALUES ('55', 'Lata', 'Yadav', 'lata.yadav55@gmail.com', 'lata55', 'pass123');
INSERT INTO `employee` VALUES ('56', 'Madhu', 'Singh', 'madhu.singh56@gmail.com', 'madhu56', 'pass123');
INSERT INTO `employee` VALUES ('57', 'Naresh', 'Kumar', 'naresh.kumar57@gmail.com', 'naresh57', 'pass123');
INSERT INTO `employee` VALUES ('58', 'Ojas', 'Joshi', 'ojas.joshi58@gmail.com', 'ojas58', 'pass123');
INSERT INTO `employee` VALUES ('59', 'Priti', 'Mehta', 'priti.mehta59@gmail.com', 'priti59', 'pass123');
INSERT INTO `employee` VALUES ('60', 'Qadir', 'Agarwal', 'qadir.agarwal60@gmail.com', 'qadir60', 'pass123');
INSERT INTO `employee` VALUES ('61', 'Ravi', 'Sharma', 'ravi.sharma61@gmail.com', 'ravi61', 'pass123');
INSERT INTO `employee` VALUES ('62', 'Sachin', 'Verma', 'sachin.verma62@gmail.com', 'sachin62', 'pass123');
INSERT INTO `employee` VALUES ('63', 'Tanvi', 'Patel', 'tanvi.patel63@gmail.com', 'tanvi63', 'pass123');
INSERT INTO `employee` VALUES ('64', 'Umesh', 'Gupta', 'umesh.gupta64@gmail.com', 'umesh64', 'pass123');
INSERT INTO `employee` VALUES ('65', 'Vandana', 'Yadav', 'vandana.yadav65@gmail.com', 'vandana65', 'pass123');
INSERT INTO `employee` VALUES ('66', 'Wasim', 'Singh', 'wasim.singh66@gmail.com', 'wasim66', 'pass123');
INSERT INTO `employee` VALUES ('67', 'Xavier', 'Kumar', 'xavier.kumar67@gmail.com', 'xavier67', 'pass123');
INSERT INTO `employee` VALUES ('68', 'Yamini', 'Joshi', 'yamini.joshi68@gmail.com', 'yamini68', 'pass123');
INSERT INTO `employee` VALUES ('69', 'Zoya', 'Mehta', 'zoya.mehta69@gmail.com', 'zoya69', 'pass123');
INSERT INTO `employee` VALUES ('70', 'Aakash', 'Agarwal', 'aakash.agarwal70@gmail.com', 'aakash70', 'pass123');
INSERT INTO `employee` VALUES ('71', 'Bharat', 'Sharma', 'bharat.sharma71@gmail.com', 'bharat71', 'pass123');
INSERT INTO `employee` VALUES ('72', 'Chirag', 'Verma', 'chirag.verma72@gmail.com', 'chirag72', 'pass123');
INSERT INTO `employee` VALUES ('73', 'Dinesh', 'Patel', 'dinesh.patel73@gmail.com', 'dinesh73', 'pass123');
INSERT INTO `employee` VALUES ('74', 'Ekta', 'Gupta', 'ekta.gupta74@gmail.com', 'ekta74', 'pass123');
INSERT INTO `employee` VALUES ('75', 'Farhan', 'Yadav', 'farhan.yadav75@gmail.com', 'farhan75', 'pass123');
INSERT INTO `employee` VALUES ('76', 'Geeta', 'Singh', 'geeta.singh76@gmail.com', 'geeta76', 'pass123');
INSERT INTO `employee` VALUES ('77', 'Himanshu', 'Kumar', 'himanshu.kumar77@gmail.com', 'himanshu77', 'pass123');
INSERT INTO `employee` VALUES ('78', 'Indu', 'Joshi', 'indu.joshi78@gmail.com', 'indu78', 'pass123');
INSERT INTO `employee` VALUES ('79', 'Jatin', 'Mehta', 'jatin.mehta79@gmail.com', 'jatin79', 'pass123');
INSERT INTO `employee` VALUES ('80', 'Kunal', 'Agarwal', 'kunal.agarwal80@gmail.com', 'kunal80', 'pass123');
INSERT INTO `employee` VALUES ('81', 'Leena', 'Sharma', 'leena.sharma81@gmail.com', 'leena81', 'pass123');
INSERT INTO `employee` VALUES ('82', 'Manoj', 'Verma', 'manoj.verma82@gmail.com', 'manoj82', 'pass123');
INSERT INTO `employee` VALUES ('83', 'Nikita', 'Patel', 'nikita.patel83@gmail.com', 'nikita83', 'pass123');
INSERT INTO `employee` VALUES ('84', 'Omkar', 'Gupta', 'omkar.gupta84@gmail.com', 'omkar84', 'pass123');
INSERT INTO `employee` VALUES ('85', 'Prakash', 'Yadav', 'prakash.yadav85@gmail.com', 'prakash85', 'pass123');
INSERT INTO `employee` VALUES ('86', 'Ritu', 'Singh', 'ritu.singh86@gmail.com', 'ritu86', 'pass123');
INSERT INTO `employee` VALUES ('87', 'Sonal', 'Kumar', 'sonal.kumar87@gmail.com', 'sonal87', 'pass123');
INSERT INTO `employee` VALUES ('88', 'Tejas', 'Joshi', 'tejas.joshi88@gmail.com', 'tejas88', 'pass123');
INSERT INTO `employee` VALUES ('89', 'Urvashi', 'Mehta', 'urvashi.mehta89@gmail.com', 'urvashi89', 'pass123');
INSERT INTO `employee` VALUES ('90', 'Vivek', 'Agarwal', 'vivek.agarwal90@gmail.com', 'vivek90', 'pass123');
INSERT INTO `employee` VALUES ('91', 'Anurag', 'Sharma', 'anurag.sharma91@gmail.com', 'anurag91', 'pass123');
INSERT INTO `employee` VALUES ('92', 'Bhavna', 'Verma', 'bhavna.verma92@gmail.com', 'bhavna92', 'pass123');
INSERT INTO `employee` VALUES ('93', 'Chetan', 'Patel', 'chetan.patel93@gmail.com', 'chetan93', 'pass123');
INSERT INTO `employee` VALUES ('94', 'Deepa', 'Gupta', 'deepa.gupta94@gmail.com', 'deepa94', 'pass123');
INSERT INTO `employee` VALUES ('95', 'Eshan', 'Yadav', 'eshan.yadav95@gmail.com', 'eshan95', 'pass123');
INSERT INTO `employee` VALUES ('96', 'Falguni', 'Singh', 'falguni.singh96@gmail.com', 'falguni96', 'pass123');
INSERT INTO `employee` VALUES ('97', 'Gopal', 'Kumar', 'gopal.kumar97@gmail.com', 'gopal97', 'pass123');
INSERT INTO `employee` VALUES ('98', 'Hema', 'Joshi', 'hema.joshi98@gmail.com', 'hema98', 'pass123');
INSERT INTO `employee` VALUES ('99', 'Irfan', 'Mehta', 'irfan.mehta99@gmail.com', 'irfan99', 'pass123');
INSERT INTO `employee` VALUES ('100', 'Jaya', 'Agarwal', 'jaya.agarwal100@gmail.com', 'jaya100', 'pass123');
INSERT INTO `employee` VALUES ('101', 'Ramu', 'Sharma', 'ramu.sharma@gmail.com', 'ramu_sharma', 'Password@123');
INSERT INTO `employee` VALUES ('102', 'Ramu', 'Sharma', 'ramu.sharma@gmail.com', 'ramu_sharma', 'Password@123');

package com.company.ems.service;

import java.util.List;

import com.company.ems.dao.EmployeeDAO;
import com.company.ems.dao.EmployeeDAOImpl;
import com.company.ems.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	private EmployeeDAO employeeDao=new EmployeeDAOImpl();

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployees();
	}

	@Override
	public Employee findById(int id) {
		// TODO Auto-generated method stub
		return employeeDao.findById(id);
	}

	@Override
	public Employee save(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDao.save(employee);
	}

	@Override
	public Employee update(Employee employee, int id) {
		// TODO Auto-generated method stub
		return employeeDao.update(employee, id);
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return employeeDao.delete(id);
	}

}

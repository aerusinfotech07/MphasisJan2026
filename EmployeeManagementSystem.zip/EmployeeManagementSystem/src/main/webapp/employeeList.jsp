<%@page import="com.ems.model.Employee"%>
<%@page import="java.util.List"%>
<%@page import="com.ems.dao.EmployeeDAOImpl"%>
<%@page import="com.ems.dao.EmployeeDAO"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<table>
<tr>
<th>Id</th>
<th>firstName</th>
<th>lastName</th>
<th>email</th>
<th>userName</th>
<th>password</th>
</tr>

</table>
<%
EmployeeDAO employeeDAO=new EmployeeDAOImpl();
List<Employee> empList=employeeDAO.findAllEmployees();
for(Employee employee:empList)
{
%>
<tr>
<td>Id</td>
<td><%=employee.getFirstName() %></td>
<td><%=employee.getLastName() %></td>
<td><%=employee.getEmail() %></td>
<td><%=employee.getUserName() %></td>
<td><%=employee.getPassword() %></td>
</tr>
<%			

}
%>
</body>
</html>
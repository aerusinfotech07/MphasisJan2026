package com.ems.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ems.model.Employee;
import com.ems.utility.DBConnection;

public class EmployeeDAOImpl implements EmployeeDAO{

	@Override
	public List<Employee> findAllEmployees() {
		Connection conn=DBConnection.getConnection();
		Statement stmt;
		ResultSet rs;
		List<Employee> employeeList=new ArrayList<>();
		try {
			stmt = conn.createStatement();
			rs=stmt.executeQuery("select * from Employee");
			while(rs.next())
			{
				Employee employee=new Employee();
				employee.setId(rs.getInt("id"));
				employee.setFirstName(rs.getString("FIRST_NAME"));
				employee.setLastName(rs.getString("LAST_NAME"));
				employee.setEmail(rs.getString("EMAIL"));
				employee.setUserName(rs.getString("USER_NAME"));
				employee.setPassword(rs.getString("PASSWORD"));
				employeeList.add(employee);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return employeeList;
	}

	@Override
	public boolean deleteById(int id) {
		Connection connection=DBConnection.getConnection();
		try {
			Statement statement=connection.createStatement();
			int noOfRecordsDeleted=statement.executeUpdate("delete from employee where id="+id);
			if(noOfRecordsDeleted>0)
				return true;
			else
				return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public Employee save(Employee employee) {
		Connection connection=DBConnection.getConnection();
		try {
			Statement statement=connection.createStatement();
			int noOfRecordsDeleted=statement.executeUpdate("insert into employee(first_name,last_name,email,user_name,password) values('"+employee.getFirstName()+"','"+employee.getLastName()+"','"+employee.getEmail()E+"','"+employee.getUserName()+"','"+employee.getPassword()+"')");
			if(noOfRecordsDeleted>0)
				return employee;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employee;
	}

	@Override
	public Employee update(Employee employee, int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findByUserName(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee findById(int id) {
		Connection conn=DBConnection.getConnection();
		Statement stmt;
		ResultSet rs;
		try {
			stmt = conn.createStatement();
			rs=stmt.executeQuery("select * from Employee where id="+id);
			if(rs.next())
			{
				Employee employee=new Employee();
				employee.setId(rs.getInt("id"));
				employee.setFirstName(rs.getString("FIRST_NAME"));
				employee.setLastName(rs.getString("LAST_NAME"));
				employee.setEmail(rs.getString("EMAIL"));
				employee.setUserName(rs.getString("USER_NAME"));
				employee.setPassword(rs.getString("PASSWORD"));
				return employee;
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return null;
	}

}
